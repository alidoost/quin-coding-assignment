import Launches from "./components/LaunchesList";
import MainContent from "./components/layout/MainContent";
import './styles/global.scss'
function App() {
  return (
    <div>
      <MainContent />
    </div>
  );
}

export default App;
